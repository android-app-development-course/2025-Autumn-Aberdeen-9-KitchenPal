package com.example.kitchenpal.data.repository

import com.example.kitchenpal.data.dao.RecipeDao
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.Recipe
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.data.repository.ShoppingRepository

@Singleton
class RecipeRepository @Inject constructor(
    private val recipeDao: RecipeDao
) {
    fun getAllRecipes(): Flow<List<Recipe>> = recipeDao.getAllRecipes()

    suspend fun addRecipe(recipe: Recipe): Long = recipeDao.insertRecipe(recipe)

    suspend fun addRecipes(recipes: List<Recipe>) = recipeDao.insertRecipes(recipes)

    suspend fun getRecipeById(id: Long): Recipe? = recipeDao.getRecipeById(id)

    // 改进的匹配度计算方法
    fun calculateMatchScore(recipe: Recipe, inventory: List<FoodItem>): Float {
        if (recipe.ingredients.isEmpty()) return 0f

        val inventoryNames = inventory.map { it.name.lowercase() }.toSet()
        val matchingIngredients = recipe.ingredients.count { ingredient ->
            inventoryNames.any { inventoryName ->
                inventoryName.contains(ingredient.lowercase()) ||
                        ingredient.lowercase().contains(inventoryName)
            }
        }

        return matchingIngredients.toFloat() / recipe.ingredients.size
    }

    fun getMissingIngredients(recipe: Recipe, inventory: List<FoodItem>): List<String> {
        val inventoryNames = inventory.map { it.name.lowercase() }.toSet()
        return recipe.ingredients.filter { ingredient ->
            !inventoryNames.any { inventoryName ->
                inventoryName.contains(ingredient.lowercase()) ||
                        ingredient.lowercase().contains(inventoryName)
            }
        }
    }

    // 获取匹配度最高的食谱
    suspend fun getMatchingRecipes(
        inventory: List<FoodItem>,
        limit: Int = 4
    ): List<Pair<Recipe, Float>> {
        val allRecipes = recipeDao.getAllRecipes().firstOrNull() ?: return emptyList()

        return allRecipes
            .map { recipe ->
                Pair(recipe, calculateMatchScore(recipe, inventory))
            }
            .sortedByDescending { it.second } // 按匹配度降序排序
            .take(limit)
    }

    // 获取评分最高的食谱
    suspend fun getTopRatedRecipes(limit: Int = 4): List<Recipe> {
        return recipeDao.getTopRatedRecipes(limit)
    }

    // 根据类别获取食谱
    suspend fun getRecipesByCategory(category: String, limit: Int = 4): List<Recipe> {
        return recipeDao.getRecipesByCategory(category, limit)
    }

    // 搜索食谱
    suspend fun searchRecipes(query: String): List<Recipe> {
        return recipeDao.searchRecipes(query)
    }


}
