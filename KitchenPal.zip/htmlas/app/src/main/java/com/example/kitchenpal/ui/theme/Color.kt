package com.example.kitchenpal.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors
val PrimaryGreen = Color(0xFF4CAF50)
val PrimaryGreenDark = Color(0xFF2E7D32)
val PrimaryGreenLight = Color(0xFF81C784)

// Background Colors
val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val CardBackground = Color(0xFFE8F5E9)

// Status Colors
val StatusFresh = Color(0xFF4CAF50)
val StatusNormal = Color(0xFF4CAF50)
val StatusNormalBackground = Color(0xFFE8F5E9)
val StatusWarning = Color(0xFFFF9800)
val StatusWarningBackground = Color(0xFFFFF3E0)
val StatusCritical = Color(0xFFF44336)
val StatusCriticalBackground = Color(0xFFFFEBEE)

// Text Colors
val TextPrimary = Color(0xFF333333)
val TextSecondary = Color(0xFF666666)
val TextHint = Color(0xFF999999)

// Other Colors
val DividerColor = Color(0xFFEEEEEE)
val IconGray = Color(0xFF999999)
