package com.example.kitchenpal.data.repository

import com.example.kitchenpal.data.dao.UserDao
import com.example.kitchenpal.data.model.User
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(
    private val userDao: UserDao
) {
    fun getUser(): Flow<User?> = userDao.getUser()
    
    suspend fun getUserSync(): User? = userDao.getUserSync()
    
    suspend fun login(username: String): Boolean {
        val user = User(id = 1, username = username, isLoggedIn = true)
        userDao.insertUser(user)
        return true
    }
    
    suspend fun logout() {
        val user = userDao.getUserSync()
        user?.let {
            userDao.updateUser(it.copy(isLoggedIn = false))
        }
    }
    
    suspend fun isLoggedIn(): Boolean {
        return userDao.getUserSync()?.isLoggedIn == true
    }
}
