package com.example.kitchenpal.data.dao

import androidx.room.*
import com.example.kitchenpal.data.model.Recipe
import kotlinx.coroutines.flow.Flow

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes ORDER BY name ASC")
    fun getAllRecipes(): Flow<List<Recipe>>
    
    @Query("SELECT * FROM recipes WHERE id = :id")
    suspend fun getRecipeById(id: Long): Recipe?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipe(recipe: Recipe): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipes(recipes: List<Recipe>)
    
    @Update
    suspend fun updateRecipe(recipe: Recipe)
    
    @Delete
    suspend fun deleteRecipe(recipe: Recipe)
    
    @Query("DELETE FROM recipes")
    suspend fun deleteAllRecipes()

    @Query("SELECT * FROM recipes WHERE name LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    suspend fun searchRecipes(query: String): List<Recipe>

    // 获取评分最高的食谱
    @Query("SELECT * FROM recipes ORDER BY rating DESC LIMIT :limit")
    suspend fun getTopRatedRecipes(limit: Int = 4): List<Recipe>

    // 获取特定类别的食谱
    @Query("SELECT * FROM recipes WHERE category = :category LIMIT :limit")
    suspend fun getRecipesByCategory(category: String, limit: Int = 4): List<Recipe>
}

