package com.example.kitchenpal.ui.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Home : Screen("home")
    object Inventory : Screen("inventory")
    object Recipes : Screen("recipes")
    object RecipeDetail : Screen("recipe_detail/{recipeId}") {
        fun createRoute(recipeId: Long) = "recipe_detail/$recipeId"
    }
    object Profile : Screen("profile")
    object ManualInput : Screen("manual_input")
    object EditFoodItem : Screen("edit_food_item/{foodItemId}") {
        fun createRoute(foodItemId: Long) = "edit_food_item/$foodItemId"
    }
}
