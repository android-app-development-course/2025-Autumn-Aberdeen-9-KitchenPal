package com.example.kitchenpal.data

import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.Recipe
import com.example.kitchenpal.data.model.StorageLocation
import java.time.LocalDate

object SampleData {

    val sampleFoodItems = listOf(
        FoodItem(
            name = "胡萝卜",
            category = FoodCategory.VEGETABLE,
            quantity = "3根",
            expiryDate = LocalDate.now().plusDays(2),
            storageLocation = StorageLocation.REFRIGERATOR
        ),
        FoodItem(
            name = "切达奶酪",
            category = FoodCategory.OTHER,
            quantity = "200g",
            expiryDate = LocalDate.now(),
            storageLocation = StorageLocation.REFRIGERATOR
        ),
        FoodItem(
            name = "红富士苹果",
            category = FoodCategory.FRUIT,
            quantity = "5个",
            expiryDate = LocalDate.now().plusDays(7),
            storageLocation = StorageLocation.COUNTER
        ),
        FoodItem(
            name = "鸡胸肉",
            category = FoodCategory.MEAT,
            quantity = "500g",
            expiryDate = LocalDate.now().plusDays(4),
            storageLocation = StorageLocation.FREEZER
        ),
        FoodItem(
            name = "纯牛奶",
            category = FoodCategory.BEVERAGE,
            quantity = "1L",
            expiryDate = LocalDate.now().plusDays(6),
            storageLocation = StorageLocation.REFRIGERATOR
        )
    )

    val sampleRecipes = listOf(
        Recipe(
            name = "胡萝卜奶酪沙拉",
            cookingTime = 15,
            calories = 210,
            ingredients = listOf("胡萝卜", "奶酪", "沙拉酱")
        ),
        Recipe(
            name = "苹果鸡肉沙拉",
            cookingTime = 20,
            calories = 320,
            ingredients = listOf("苹果", "鸡胸肉", "生菜")
        ),
        Recipe(
            name = "奶酪三明治",
            cookingTime = 10,
            calories = 280,
            ingredients = listOf("奶酪", "面包片", "黄油")
        ),
        Recipe(
            name = "胡萝卜苹果汁",
            cookingTime = 5,
            calories = 120,
            ingredients = listOf("胡萝卜", "苹果")
        )
    )
}