package com.example.kitchenpal.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.kitchenpal.ui.navigation.Screen
import com.example.kitchenpal.ui.theme.*

data class BottomNavItem(
    val route: String,
    val icon: ImageVector,
    val label: String
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Home.route, Icons.Default.Home, "首页"),
    BottomNavItem(Screen.Inventory.route, Icons.Default.Inventory2, "库存"),
    BottomNavItem(Screen.Recipes.route, Icons.Default.Restaurant, "膳食"),
    BottomNavItem(Screen.Profile.route, Icons.Default.Person, "我的")
)

@Composable
fun BottomNavigationBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    NavigationBar(
        containerColor = SurfaceLight
    ) {
        bottomNavItems.forEach { item ->
            val isSelected = currentRoute == item.route || currentRoute.startsWith(item.route)
            NavigationBarItem(
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label
                    )
                },
                label = { Text(text = item.label) },
                selected = isSelected,
                onClick = { 
                    if (currentRoute != item.route) {
                        onNavigate(item.route) 
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PrimaryGreen,
                    selectedTextColor = PrimaryGreen,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = CardBackground
                )
            )
        }
    }
}
