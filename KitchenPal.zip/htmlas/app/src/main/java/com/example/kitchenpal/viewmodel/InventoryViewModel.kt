package com.example.kitchenpal.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.StorageLocation
import com.example.kitchenpal.data.repository.FoodRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class InventoryUiState(
    val foodItems: List<FoodItem> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = true
)

data class ManualInputState(
    val name: String = "",
    val category: FoodCategory = FoodCategory.VEGETABLE,
    val quantity: String = "",
    val expiryDate: LocalDate = LocalDate.now().plusDays(7),
    val storageLocation: StorageLocation = StorageLocation.REFRIGERATOR,
    val isSaving: Boolean = false,
    val saveSuccess: Boolean = false,
    val errorMessage: String? = null
)

data class EditFoodItemState(
    val id: Long = 0,
    val name: String = "",
    val category: FoodCategory = FoodCategory.VEGETABLE,
    val quantity: String = "",
    val expiryDate: LocalDate = LocalDate.now().plusDays(7),
    val storageLocation: StorageLocation = StorageLocation.REFRIGERATOR,
    val isSaving: Boolean = false,
    val saveSuccess: Boolean = false,
    val errorMessage: String? = null
)

@HiltViewModel
class InventoryViewModel @Inject constructor(
    private val foodRepository: FoodRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(InventoryUiState())
    val uiState: StateFlow<InventoryUiState> = _uiState.asStateFlow()
    
    private val _manualInputState = MutableStateFlow(ManualInputState())
    val manualInputState: StateFlow<ManualInputState> = _manualInputState.asStateFlow()
    
    private val _editState = MutableStateFlow(EditFoodItemState())
    val editState: StateFlow<EditFoodItemState> = _editState.asStateFlow()
    
    init {
        loadFoodItems()
    }
    
    private fun loadFoodItems() {
        viewModelScope.launch {
            foodRepository.getAllFoodItems().collect { items ->
                _uiState.value = _uiState.value.copy(
                    foodItems = items,
                    isLoading = false
                )
            }
        }
    }
    
    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }
    
    fun getFilteredItems(): List<FoodItem> {
        val query = _uiState.value.searchQuery.lowercase()
        return if (query.isEmpty()) {
            _uiState.value.foodItems
        } else {
            _uiState.value.foodItems.filter { 
                it.name.lowercase().contains(query) 
            }
        }
    }
    
    fun deleteFoodItem(item: FoodItem) {
        viewModelScope.launch {
            foodRepository.deleteFoodItem(item)
        }
    }
    
    // Manual Input functions
    fun updateName(name: String) {
        _manualInputState.value = _manualInputState.value.copy(name = name, errorMessage = null)
    }
    
    fun updateCategory(category: FoodCategory) {
        _manualInputState.value = _manualInputState.value.copy(category = category)
    }
    
    fun updateQuantity(quantity: String) {
        _manualInputState.value = _manualInputState.value.copy(quantity = quantity)
    }
    
    fun updateExpiryDate(date: LocalDate) {
        _manualInputState.value = _manualInputState.value.copy(expiryDate = date)
    }
    
    fun updateStorageLocation(location: StorageLocation) {
        _manualInputState.value = _manualInputState.value.copy(storageLocation = location)
    }
    
    fun saveFoodItem() {
        val state = _manualInputState.value
        
        if (state.name.isBlank()) {
            _manualInputState.value = state.copy(errorMessage = "请输入食品名称")
            return
        }
        
        if (state.quantity.isBlank()) {
            _manualInputState.value = state.copy(errorMessage = "请输入数量")
            return
        }
        
        viewModelScope.launch {
            _manualInputState.value = state.copy(isSaving = true)
            try {
                val foodItem = FoodItem(
                    name = state.name,
                    category = state.category,
                    quantity = state.quantity,
                    expiryDate = state.expiryDate,
                    storageLocation = state.storageLocation
                )
                foodRepository.addFoodItem(foodItem)
                _manualInputState.value = _manualInputState.value.copy(
                    isSaving = false,
                    saveSuccess = true
                )
            } catch (e: Exception) {
                _manualInputState.value = _manualInputState.value.copy(
                    isSaving = false,
                    errorMessage = "保存失败，请重试"
                )
            }
        }
    }
    
    fun resetManualInputState() {
        _manualInputState.value = ManualInputState()
    }
    
    // Edit functions
    fun loadFoodItemForEdit(id: Long) {
        viewModelScope.launch {
            val item = foodRepository.getFoodItemById(id)
            if (item != null) {
                _editState.value = EditFoodItemState(
                    id = item.id,
                    name = item.name,
                    category = item.category,
                    quantity = item.quantity,
                    expiryDate = item.expiryDate,
                    storageLocation = item.storageLocation
                )
            }
        }
    }
    
    fun updateEditName(name: String) {
        _editState.value = _editState.value.copy(name = name, errorMessage = null)
    }
    
    fun updateEditCategory(category: FoodCategory) {
        _editState.value = _editState.value.copy(category = category)
    }
    
    fun updateEditQuantity(quantity: String) {
        _editState.value = _editState.value.copy(quantity = quantity)
    }
    
    fun updateEditExpiryDate(date: LocalDate) {
        _editState.value = _editState.value.copy(expiryDate = date)
    }
    
    fun updateEditStorageLocation(location: StorageLocation) {
        _editState.value = _editState.value.copy(storageLocation = location)
    }
    
    fun updateFoodItem() {
        val state = _editState.value
        
        if (state.name.isBlank()) {
            _editState.value = state.copy(errorMessage = "请输入食品名称")
            return
        }
        
        if (state.quantity.isBlank()) {
            _editState.value = state.copy(errorMessage = "请输入数量")
            return
        }
        
        viewModelScope.launch {
            _editState.value = state.copy(isSaving = true)
            try {
                val foodItem = FoodItem(
                    id = state.id,
                    name = state.name,
                    category = state.category,
                    quantity = state.quantity,
                    expiryDate = state.expiryDate,
                    storageLocation = state.storageLocation
                )
                foodRepository.updateFoodItem(foodItem)
                _editState.value = _editState.value.copy(
                    isSaving = false,
                    saveSuccess = true
                )
            } catch (e: Exception) {
                _editState.value = _editState.value.copy(
                    isSaving = false,
                    errorMessage = "保存失败，请重试"
                )
            }
        }
    }
    
    fun resetEditState() {
        _editState.value = EditFoodItemState()
    }
}
