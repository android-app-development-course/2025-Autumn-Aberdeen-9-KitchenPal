package com.example.kitchenpal.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.ui.components.FoodItemCard
import com.example.kitchenpal.ui.theme.*
import com.example.kitchenpal.viewmodel.InventoryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    onNavigateToEdit: (Long) -> Unit = {},
    onNavigateToAdd: () -> Unit = {},
    viewModel: InventoryViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val filteredItems = viewModel.getFilteredItems()
    var showSearch by remember { mutableStateOf(false) }
    var selectedItem by remember { mutableStateOf<FoodItem?>(null) }
    var showActionDialog by remember { mutableStateOf(false) }
    
    // Action Dialog
    if (showActionDialog && selectedItem != null) {
        AlertDialog(
            onDismissRequest = { 
                showActionDialog = false
                selectedItem = null
            },
            title = { Text(selectedItem!!.name) },
            text = { Text("请选择操作") },
            confirmButton = {
                Row {
                    TextButton(
                        onClick = {
                            onNavigateToEdit(selectedItem!!.id)
                            showActionDialog = false
                            selectedItem = null
                        }
                    ) {
                        Text("编辑", color = PrimaryGreen)
                    }
                    TextButton(
                        onClick = {
                            viewModel.deleteFoodItem(selectedItem!!)
                            showActionDialog = false
                            selectedItem = null
                        }
                    ) {
                        Text("删除", color = StatusCritical)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { 
                        showActionDialog = false
                        selectedItem = null
                    }
                ) {
                    Text("取消", color = TextSecondary)
                }
            }
        )
    }
    
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))
        
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "库存管理",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryGreenDark
                )
                Text(
                    text = "共 ${uiState.foodItems.size} 种食材",
                    fontSize = 14.sp,
                    color = TextSecondary
                )
            }
            IconButton(onClick = { showSearch = !showSearch }) {
                Icon(
                    imageVector = if (showSearch) Icons.Default.Close else Icons.Default.Search,
                    contentDescription = "搜索",
                    tint = PrimaryGreen,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
        
        // Search Bar
        AnimatedVisibility(
            visible = showSearch,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                placeholder = { Text("搜索食材...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "清除",
                                tint = TextSecondary
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(16.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryGreen,
                    cursorColor = PrimaryGreen
                )
            )
        }
        
        Spacer(modifier = Modifier.height(if (showSearch) 0.dp else 16.dp))
        
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PrimaryGreen)
            }
        } else if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = if (uiState.searchQuery.isNotEmpty()) 
                            Icons.Default.SearchOff else Icons.Default.Inventory2,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = TextSecondary.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (uiState.searchQuery.isNotEmpty()) 
                            "未找到 \"${uiState.searchQuery}\"" else "暂无库存食材",
                        color = TextSecondary,
                        fontSize = 16.sp
                    )
                    if (uiState.searchQuery.isEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "点击右下角按钮添加食材",
                            color = TextSecondary.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(top = 8.dp)
            ) {
                items(
                    items = filteredItems,
                    key = { it.id }
                ) { item ->
                    SwipeToDeleteItem(
                        item = item,
                        onDelete = { viewModel.deleteFoodItem(item) },
                        onClick = {
                            selectedItem = item
                            showActionDialog = true
                        }
                    )
                }
                
                item {
                    Spacer(modifier = Modifier.height(140.dp))
                }
            }
        }
        }
        
        // FAB
        FloatingActionButton(
            onClick = onNavigateToAdd,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 100.dp),
            containerColor = PrimaryGreen,
            contentColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "添加食材"
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SwipeToDeleteItem(
    item: FoodItem,
    onDelete: () -> Unit,
    onClick: () -> Unit = {}
) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { dismissValue ->
            if (dismissValue == SwipeToDismissBoxValue.EndToStart) {
                showDeleteDialog = true
                false
            } else {
                false
            }
        }
    )
    
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("确认删除") },
            text = { Text("确定要删除 \"${item.name}\" 吗？") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete()
                        showDeleteDialog = false
                    }
                ) {
                    Text("删除", color = StatusCritical)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("取消", color = TextSecondary)
                }
            }
        )
    }
    
    SwipeToDismissBox(
        state = dismissState,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        StatusCritical.copy(alpha = 0.1f),
                        RoundedCornerShape(15.dp)
                    )
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "删除",
                    tint = StatusCritical
                )
            }
        },
        content = {
            FoodItemCard(foodItem = item, onClick = onClick)
        },
        enableDismissFromStartToEnd = false,
        enableDismissFromEndToStart = true
    )
}
