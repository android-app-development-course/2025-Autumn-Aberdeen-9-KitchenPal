package com.example.kitchenpal.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.data.repository.ShoppingRepository
import com.example.kitchenpal.data.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProfileUiState(
    val shoppingItems: List<ShoppingItem> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val shoppingRepository: ShoppingRepository,
    private val userRepository: UserRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()
    
    init {
        loadShoppingItems()
    }
    
    private fun loadShoppingItems() {
        viewModelScope.launch {
            shoppingRepository.getAllShoppingItems().collect { items ->
                _uiState.value = ProfileUiState(
                    shoppingItems = items,
                    isLoading = false
                )
            }
        }
    }
    
    fun toggleShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            shoppingRepository.toggleShoppingItem(item)
        }
    }
    
    fun deleteShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            shoppingRepository.deleteShoppingItem(item)
        }
    }
    
    fun addShoppingItem(name: String, quantity: String) {
        if (name.isBlank()) return
        
        viewModelScope.launch {
            val item = ShoppingItem(
                name = name,
                quantity = quantity.ifBlank { "1" }
            )
            shoppingRepository.addShoppingItem(item)
        }
    }
    
    fun logout() {
        viewModelScope.launch {
            userRepository.logout()
        }
    }
}
