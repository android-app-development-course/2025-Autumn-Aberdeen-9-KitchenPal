package com.example.kitchenpal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey
    val id: Long = 1,
    val username: String,
    val isLoggedIn: Boolean = false
)
