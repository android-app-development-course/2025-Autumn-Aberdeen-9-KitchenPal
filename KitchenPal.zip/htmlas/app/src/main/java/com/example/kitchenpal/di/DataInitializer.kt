package com.example.kitchenpal.di

import com.example.kitchenpal.data.SampleData
import com.example.kitchenpal.data.dao.FoodItemDao
import com.example.kitchenpal.data.dao.RecipeDao
import com.example.kitchenpal.data.dao.ShoppingItemDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataInitializer @Inject constructor(
    private val foodItemDao: FoodItemDao,
    private val recipeDao: RecipeDao,
    private val shoppingItemDao: ShoppingItemDao
) {
    fun initializeData() {
        CoroutineScope(Dispatchers.IO).launch {
            // Check if data already exists
            val existingFoodItems = foodItemDao.getAllFoodItems().first()
            if (existingFoodItems.isEmpty()) {
                // Insert sample food items
                SampleData.sampleFoodItems.forEach { item ->
                    foodItemDao.insertFoodItem(item)
                }
            }
            
            val existingRecipes = recipeDao.getAllRecipes().first()
            if (existingRecipes.isEmpty()) {
                // Insert sample recipes
                recipeDao.insertRecipes(SampleData.sampleRecipes)
            }
            
            val existingShoppingItems = shoppingItemDao.getAllShoppingItems().first()
            if (existingShoppingItems.isEmpty()) {
            }
        }
    }
}
