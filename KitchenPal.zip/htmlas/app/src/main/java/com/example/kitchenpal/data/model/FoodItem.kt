package com.example.kitchenpal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.LocalDateTime
import androidx.room.Index

@Entity(
    tableName = "food_items",
    indices = [Index(value = ["name"], unique = true)]
)
data class FoodItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: FoodCategory,
    val quantity: String,
    val expiryDate: LocalDate,
    val storageLocation: StorageLocation,
    val createdAt: LocalDateTime = LocalDateTime.now()
)

enum class FoodCategory(val displayName: String, val icon: String) {
    VEGETABLE("蔬菜", "🥬"),
    FRUIT("水果", "🍎"),
    MEAT("肉类", "🍖"),
    BEVERAGE("饮品", "🥤"),
    GRAIN("谷物", "🌾"),
    CONDIMENT("调味品", "🧂"),
    OTHER("其他", "📦")
}

enum class StorageLocation(val displayName: String, val icon: String) {
    REFRIGERATOR("冰箱冷藏室", "❄️"),
    FREEZER("冰箱冷冻室", "🧊"),
    PANTRY("储藏室", "🏠"),
    COUNTER("厨房台面", "🍽️")
}

enum class ExpiryStatus {
    NORMAL,     // 正常 (>3天)
    WARNING,    // 即将过期 (1-3天)
    CRITICAL    // 已过期或今天过期
}

data class CategoryCount(
    val category: FoodCategory,
    val count: Int
)
