package com.example.kitchenpal.util

import com.example.kitchenpal.data.model.ExpiryStatus
import java.time.LocalDate
import java.time.temporal.ChronoUnit

fun calculateExpiryStatus(expiryDate: LocalDate, currentDate: LocalDate = LocalDate.now()): ExpiryStatus {
    val daysDiff = ChronoUnit.DAYS.between(currentDate, expiryDate)
    return when {
        daysDiff <= 0 -> ExpiryStatus.CRITICAL
        daysDiff <= 3 -> ExpiryStatus.WARNING
        else -> ExpiryStatus.NORMAL
    }
}

fun getDaysUntilExpiry(expiryDate: LocalDate, currentDate: LocalDate = LocalDate.now()): Long {
    return ChronoUnit.DAYS.between(currentDate, expiryDate)
}

fun formatExpiryText(daysUntilExpiry: Long): String {
    return when {
        daysUntilExpiry < 0 -> "已过期${-daysUntilExpiry}天"
        daysUntilExpiry == 0L -> "今天过期"
        daysUntilExpiry == 1L -> "明天过期"
        else -> "${daysUntilExpiry}天后过期"
    }
}
