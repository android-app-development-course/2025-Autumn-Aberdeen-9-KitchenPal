package com.example.kitchenpal.data.dao

import androidx.room.*
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Dao
interface FoodItemDao {
    @Query("SELECT * FROM food_items ORDER BY expiryDate ASC")
    fun getAllFoodItems(): Flow<List<FoodItem>>
    
    @Query("SELECT * FROM food_items WHERE category = :category ORDER BY expiryDate ASC")
    fun getFoodItemsByCategory(category: FoodCategory): Flow<List<FoodItem>>
    
    @Query("SELECT * FROM food_items WHERE expiryDate <= :date ORDER BY expiryDate ASC")
    fun getExpiringItems(date: LocalDate): Flow<List<FoodItem>>
    
    @Query("SELECT * FROM food_items WHERE id = :id")
    suspend fun getFoodItemById(id: Long): FoodItem?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFoodItem(item: FoodItem): Long
    
    @Update
    suspend fun updateFoodItem(item: FoodItem)
    
    @Delete
    suspend fun deleteFoodItem(item: FoodItem)
    
    @Query("DELETE FROM food_items")
    suspend fun deleteAllFoodItems()
}
