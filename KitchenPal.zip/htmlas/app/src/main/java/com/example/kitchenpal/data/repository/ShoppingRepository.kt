package com.example.kitchenpal.data.repository

import com.example.kitchenpal.data.dao.ShoppingItemDao
import com.example.kitchenpal.data.model.ShoppingItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ShoppingRepository @Inject constructor(
    private val shoppingItemDao: ShoppingItemDao
) {
    fun getAllShoppingItems(): Flow<List<ShoppingItem>> = shoppingItemDao.getAllShoppingItems()

    suspend fun addShoppingItem(item: ShoppingItem): Long = shoppingItemDao.insertShoppingItem(item)

    suspend fun updateShoppingItem(item: ShoppingItem) = shoppingItemDao.updateShoppingItem(item)

    suspend fun deleteShoppingItem(item: ShoppingItem) = shoppingItemDao.deleteShoppingItem(item)

    suspend fun toggleShoppingItem(item: ShoppingItem) {
        shoppingItemDao.updateShoppingItem(item.copy(isChecked = !item.isChecked))
    }

    suspend fun getShoppingItemById(id: Long): ShoppingItem? = shoppingItemDao.getShoppingItemById(id)

    suspend fun getShoppingItemByName(name: String): ShoppingItem? {
        return shoppingItemDao.getShoppingItemByName(name)
    }

    suspend fun isItemAlreadyExists(name: String): Boolean {
        val existingItems = getAllShoppingItems().firstOrNull() ?: emptyList()
        return existingItems.any { it.name == name && !it.isChecked }
    }

    suspend fun clearCheckedItems() {
        shoppingItemDao.deleteCheckedItems()
    }

    suspend fun addShoppingItems(items: List<ShoppingItem>) {
        items.forEach { item ->
            if (!isItemAlreadyExists(item.name)) {
                shoppingItemDao.insertShoppingItem(item)
            }
        }
    }
}