package com.example.kitchenpal.data.database

import androidx.room.TypeConverter
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.StorageLocation
import java.time.LocalDate
import java.time.LocalDateTime

class Converters {
    @TypeConverter
    fun fromLocalDate(date: LocalDate?): String? {
        return date?.toString()
    }
    
    @TypeConverter
    fun toLocalDate(dateString: String?): LocalDate? {
        return dateString?.let { LocalDate.parse(it) }
    }
    
    @TypeConverter
    fun fromLocalDateTime(dateTime: LocalDateTime?): String? {
        return dateTime?.toString()
    }
    
    @TypeConverter
    fun toLocalDateTime(dateTimeString: String?): LocalDateTime? {
        return dateTimeString?.let { LocalDateTime.parse(it) }
    }
    
    @TypeConverter
    fun fromFoodCategory(category: FoodCategory): String {
        return category.name
    }
    
    @TypeConverter
    fun toFoodCategory(categoryName: String): FoodCategory {
        return FoodCategory.valueOf(categoryName)
    }
    
    @TypeConverter
    fun fromStorageLocation(location: StorageLocation): String {
        return location.name
    }
    
    @TypeConverter
    fun toStorageLocation(locationName: String): StorageLocation {
        return StorageLocation.valueOf(locationName)
    }
    
    @TypeConverter
    fun fromStringList(list: List<String>): String {
        return list.joinToString(separator = "|||")
    }
    
    @TypeConverter
    fun toStringList(data: String): List<String> {
        return if (data.isEmpty()) emptyList() else data.split("|||")
    }

    @TypeConverter
    fun fromFloat(value: Float?): String? {
        return value?.toString()
    }

    @TypeConverter
    fun toFloat(value: String?): Float? {
        return value?.toFloatOrNull()
    }
}
