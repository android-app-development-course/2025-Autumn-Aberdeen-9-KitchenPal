package com.example.kitchenpal.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.kitchenpal.data.dao.FoodItemDao
import com.example.kitchenpal.data.dao.RecipeDao
import com.example.kitchenpal.data.dao.ShoppingItemDao
import com.example.kitchenpal.data.dao.UserDao
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.Recipe
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.data.model.User

@Database(
    entities = [
        FoodItem::class,
        Recipe::class,
        ShoppingItem::class,
        User::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class KitchenPalDatabase : RoomDatabase() {
    abstract fun foodItemDao(): FoodItemDao
    abstract fun recipeDao(): RecipeDao
    abstract fun shoppingItemDao(): ShoppingItemDao
    abstract fun userDao(): UserDao
}
