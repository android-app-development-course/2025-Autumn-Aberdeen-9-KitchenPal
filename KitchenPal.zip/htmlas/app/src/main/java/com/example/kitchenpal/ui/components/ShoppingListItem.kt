package com.example.kitchenpal.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.ui.theme.*

@Composable
fun ShoppingListItem(
    item: ShoppingItem,
    onCheckedChange: (Boolean) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = item.isChecked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = PrimaryGreen,
                uncheckedColor = TextSecondary
            )
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        Text(
            text = item.name,
            modifier = Modifier.weight(1f),
            fontSize = 14.sp,
            color = if (item.isChecked) TextSecondary else TextPrimary,
            textDecoration = if (item.isChecked) TextDecoration.LineThrough else TextDecoration.None
        )
        
        Text(
            text = item.quantity,
            fontSize = 14.sp,
            color = TextSecondary
        )
        
        Spacer(modifier = Modifier.width(12.dp))
        
        IconButton(onClick = onDelete) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "删除",
                tint = StatusCritical
            )
        }
    }
}
