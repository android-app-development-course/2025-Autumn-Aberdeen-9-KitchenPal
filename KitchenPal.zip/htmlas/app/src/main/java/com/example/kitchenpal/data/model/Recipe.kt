package com.example.kitchenpal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "recipes",
    indices = [Index(value = ["name"], unique = true)]
)
data class Recipe(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val imageUrl: String? = null,
    val cookingTime: Int,  // 分钟
    val calories: Int,
    val ingredients: List<String>,
    val description: String? = null,
    val category: String? = null,
    val rating: Float = 0f,
    val difficulty: String = "简单"
)
