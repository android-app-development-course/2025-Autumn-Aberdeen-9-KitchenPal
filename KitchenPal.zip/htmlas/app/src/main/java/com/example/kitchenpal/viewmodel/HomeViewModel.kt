package com.example.kitchenpal.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kitchenpal.data.model.CategoryCount
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.repository.FoodRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val categoryCounts: List<CategoryCount> = FoodCategory.entries.map { CategoryCount(it, 0) },
    val expiringItems: List<FoodItem> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val foodRepository: FoodRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()
    
    init {
        loadData()
    }
    
    private fun loadData() {
        viewModelScope.launch {
            foodRepository.getCategoryCounts().collect { counts ->
                _uiState.value = _uiState.value.copy(categoryCounts = counts)
            }
        }
        
        viewModelScope.launch {
            foodRepository.getExpiringItems(3).collect { items ->
                _uiState.value = _uiState.value.copy(
                    expiringItems = items,
                    isLoading = false
                )
            }
        }
    }
    
    fun refresh() {
        _uiState.value = _uiState.value.copy(isLoading = true)
        loadData()
    }
}
