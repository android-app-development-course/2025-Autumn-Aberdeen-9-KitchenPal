package com.example.kitchenpal.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.kitchenpal.data.model.*
import com.example.kitchenpal.ui.theme.*
import com.example.kitchenpal.util.calculateExpiryStatus
import com.example.kitchenpal.util.formatExpiryText
import com.example.kitchenpal.util.getDaysUntilExpiry
import java.time.format.DateTimeFormatter

@Composable
fun InventoryCategoryCard(
    category: FoodCategory,
    itemCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = getCategoryIcon(category),
                contentDescription = category.displayName,
                tint = PrimaryGreen,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = category.displayName,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = "$itemCount 件",
                fontSize = 12.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun FoodItemCard(
    foodItem: FoodItem,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val expiryStatus = calculateExpiryStatus(foodItem.expiryDate)
    val daysUntilExpiry = getDaysUntilExpiry(foodItem.expiryDate)
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(CardBackground),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getCategoryIcon(foodItem.category),
                    contentDescription = null,
                    tint = PrimaryGreen,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(15.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = foodItem.name,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    ExpiryStatusBadge(expiryStatus = expiryStatus, daysUntilExpiry = daysUntilExpiry)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = foodItem.quantity,
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = foodItem.storageLocation.displayName,
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun ExpiryStatusBadge(
    expiryStatus: ExpiryStatus,
    daysUntilExpiry: Long,
    modifier: Modifier = Modifier
) {
    val (backgroundColor, textColor) = when (expiryStatus) {
        ExpiryStatus.NORMAL -> StatusNormalBackground to StatusNormal
        ExpiryStatus.WARNING -> StatusWarningBackground to StatusWarning
        ExpiryStatus.CRITICAL -> StatusCriticalBackground to StatusCritical
    }
    
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = backgroundColor
    ) {
        Text(
            text = formatExpiryText(daysUntilExpiry),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = textColor
        )
    }
}

@Composable
fun getCategoryIcon(category: FoodCategory): ImageVector {
    return when (category) {
        FoodCategory.VEGETABLE -> Icons.Default.Eco
        FoodCategory.FRUIT -> Icons.Default.Spa
        FoodCategory.MEAT -> Icons.Default.Restaurant
        FoodCategory.BEVERAGE -> Icons.Default.LocalDrink
        FoodCategory.GRAIN -> Icons.Default.Grass
        FoodCategory.CONDIMENT -> Icons.Default.Kitchen
        FoodCategory.OTHER -> Icons.Default.Inventory2
    }
}
