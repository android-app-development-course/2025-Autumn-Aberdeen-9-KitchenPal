package com.example.kitchenpal.data.repository

import com.example.kitchenpal.data.dao.FoodItemDao
import com.example.kitchenpal.data.model.CategoryCount
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FoodRepository @Inject constructor(
    private val foodItemDao: FoodItemDao
) {
    fun getAllFoodItems(): Flow<List<FoodItem>> = foodItemDao.getAllFoodItems()
    
    fun getFoodItemsByCategory(category: FoodCategory): Flow<List<FoodItem>> = 
        foodItemDao.getFoodItemsByCategory(category)
    
    fun getExpiringItems(withinDays: Int = 3): Flow<List<FoodItem>> {
        val targetDate = LocalDate.now().plusDays(withinDays.toLong())
        return foodItemDao.getExpiringItems(targetDate)
    }
    
    fun getCategoryCounts(): Flow<List<CategoryCount>> {
        return foodItemDao.getAllFoodItems().map { items ->
            FoodCategory.entries.map { category ->
                CategoryCount(
                    category = category,
                    count = items.count { it.category == category }
                )
            }
        }
    }
    
    suspend fun addFoodItem(item: FoodItem): Long = foodItemDao.insertFoodItem(item)
    
    suspend fun updateFoodItem(item: FoodItem) = foodItemDao.updateFoodItem(item)
    
    suspend fun deleteFoodItem(item: FoodItem) = foodItemDao.deleteFoodItem(item)
    
    suspend fun getFoodItemById(id: Long): FoodItem? = foodItemDao.getFoodItemById(id)
}
