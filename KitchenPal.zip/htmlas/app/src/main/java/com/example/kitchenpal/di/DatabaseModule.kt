package com.example.kitchenpal.di

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.kitchenpal.data.dao.FoodItemDao
import com.example.kitchenpal.data.dao.RecipeDao
import com.example.kitchenpal.data.dao.ShoppingItemDao
import com.example.kitchenpal.data.dao.UserDao
import com.example.kitchenpal.data.database.KitchenPalDatabase
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.Recipe
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.data.model.StorageLocation
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Provider
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
        foodItemDaoProvider: Provider<FoodItemDao>,
        recipeDaoProvider: Provider<RecipeDao>,
        shoppingItemDaoProvider: Provider<ShoppingItemDao>
    ): KitchenPalDatabase {
        return Room.databaseBuilder(
            context,
            KitchenPalDatabase::class.java,
            "kitchenpal_database"
        )
        .addCallback(object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                CoroutineScope(Dispatchers.IO).launch {
                    // 添加示例食材
                    val foodItemDao = foodItemDaoProvider.get()
                    val sampleFoodItems = listOf(
                        FoodItem(
                            name = "切达奶酪",
                            category = FoodCategory.BEVERAGE,
                            quantity = "200g",
                            expiryDate = LocalDate.now().minusDays(1),
                            storageLocation = StorageLocation.REFRIGERATOR
                        ),
                        FoodItem(
                            name = "胡萝卜",
                            category = FoodCategory.VEGETABLE,
                            quantity = "3根",
                            expiryDate = LocalDate.now().plusDays(1),
                            storageLocation = StorageLocation.REFRIGERATOR
                        ),
                        FoodItem(
                            name = "鸡胸肉",
                            category = FoodCategory.MEAT,
                            quantity = "500g",
                            expiryDate = LocalDate.now().plusDays(3),
                            storageLocation = StorageLocation.FREEZER
                        ),
                        FoodItem(
                            name = "纯牛奶",
                            category = FoodCategory.BEVERAGE,
                            quantity = "1L",
                            expiryDate = LocalDate.now().plusDays(5),
                            storageLocation = StorageLocation.REFRIGERATOR
                        ),
                        FoodItem(
                            name = "红富士苹果",
                            category = FoodCategory.FRUIT,
                            quantity = "5个",
                            expiryDate = LocalDate.now().plusDays(6),
                            storageLocation = StorageLocation.COUNTER
                        )
                    )
                    sampleFoodItems.forEach { foodItemDao.insertFoodItem(it) }
                    
                    // 添加示例菜谱
                    val recipeDao = recipeDaoProvider.get()
                    val sampleRecipes = listOf(
                        Recipe(
                            name = "奶酪三明治",
                            imageUrl = "https://pic2.zhimg.com/v2-8e7de851bd45a1a0d919ce9f3b485cc1_1440w.jpg?source=172ae18b",
                            cookingTime = 10,
                            calories = 280,
                            ingredients = listOf("面包片", "奶酪", "黄油"),
                            description = "简单的奶酪三明治，早餐好选择",
                            category = "早餐",
                            rating = 4.2f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "胡萝卜苹果汁",
                            imageUrl = "https://q5.itc.cn/q_70/images03/20250730/52399e6283f94adbb8d720ad18c3e5d5.jpeg",
                            cookingTime = 5,
                            calories = 120,
                            ingredients = listOf("胡萝卜", "苹果"),
                            description = "新鲜营养的胡萝卜苹果汁",
                            category = "饮品",
                            rating = 4.0f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "芝士焗红薯",
                            imageUrl = "https://qcloud.dpfile.com/pc/ighAJfgAUBBN4_bsxXXCrkrOaesWVnBhbqhH6R2aQha9ijqymj50mf1q0YCUXJ_W.jpg",
                            cookingTime = 25,
                            calories = 290,
                            ingredients = listOf("红薯", "芝士碎", "黄油", "白砂糖", "牛奶"),
                            description = "香甜拉丝的芝士焗红薯，追剧小零食",
                            category = "甜品",
                            rating = 4.9f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "玉米排骨汤",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%2755S15Y6L5Yqb6ZSF54KW5o6S6aqo5aSa6ZW/5pe26Ze0XzE3MzY1Mjg5MTQuODM5MTg5NQ%3D%3D%27/0.png",
                            cookingTime = 70,
                            calories = 300,
                            ingredients = listOf("排骨", "玉米", "胡萝卜", "姜片", "盐"),
                            description = "清甜不腻的玉米排骨汤，营养丰富",
                            category = "汤品",
                            rating = 4.9f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "清炒四季豆",
                            imageUrl = "https://pic.rmb.bdstatic.com/bjh/3f111230caa/240831/25add8247986d5260da16c5a9d3474ea.jpeg",
                            cookingTime = 12,
                            calories = 110,
                            ingredients = listOf("四季豆", "干辣椒", "蒜末", "盐", "生抽"),
                            description = "咸香爽脆的清炒四季豆，经典下饭菜",
                            category = "素菜",
                            rating = 4.4f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "牛奶紫薯芋圆",
                            imageUrl = "https://preview.qiantucdn.com/58pic/72/61/89/16D58PICtv5CxvPWheFxC_origin_PIC2018.png!qt_h320",
                            cookingTime = 25,
                            calories = 240,
                            ingredients = listOf("紫薯", "木薯淀粉", "白砂糖", "牛奶"),
                            description = "Q弹软糯的紫薯芋圆，搭配牛奶超满足",
                            category = "甜品",
                            rating = 4.7f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "虾仁滑蛋",
                            imageUrl = "https://q6.itc.cn/images01/20240912/dd724396945e4bec9b4437023811804b.jpeg",
                            cookingTime = 10,
                            calories = 200,
                            ingredients = listOf("虾仁", "鸡蛋", "葱花", "盐", "食用油", "淀粉"),
                            description = "嫩滑鲜香的虾仁滑蛋，高蛋白低脂肪",
                            category = "家常菜",
                            rating = 4.8f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "南瓜粥",
                            imageUrl = "https://gips0.baidu.com/it/u=4258966552,927623504&fm=3074&app=3074&f=JPEG",
                            cookingTime = 40,
                            calories = 150,
                            ingredients = listOf("南瓜", "大米", "冰糖"),
                            description = "软糯香甜的南瓜粥，养胃易消化，适合早餐",
                            category = "粥品",
                            rating = 4.7f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "可乐鸡翅",
                            imageUrl = "https://am.zdmimg.com/202504/19/6803b292bbc009470.jpg_e1080.jpg",
                            cookingTime = 30,
                            calories = 320,
                            ingredients = listOf("鸡翅", "可乐", "姜片", "生抽", "料酒", "盐"),
                            description = "甜咸入味的可乐鸡翅，大人小孩都爱吃",
                            category = "家常菜",
                            rating = 4.9f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "苹果鸡肉沙拉",
                            imageUrl = "https://gd-hbimg.huaban.com/83277aa3dde7f844b9c5859ed45f4ba1c87c0bde25b99-eqYtUe_fw658",
                            cookingTime = 20,
                            calories = 320,
                            ingredients = listOf("苹果", "鸡胸肉", "生菜", "胡萝卜", "沙拉酱"),
                            description = "丰富的苹果鸡肉沙拉，蛋白质充足",
                            category = "沙拉",
                            rating = 4.7f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "芝士焗鸡胸肉",
                            imageUrl = "https://tse2.mm.bing.net/th/id/OIP.ACzu-UacByCdXW_txc6ECwHaHa?rs=1&pid=ImgDetMain&o=7&rm=3",
                            cookingTime = 25,
                            calories = 350,
                            ingredients = listOf("鸡胸肉", "奶酪", "胡萝卜", "土豆"),
                            description = "美味的芝士焗鸡胸肉",
                            category = "主菜",
                            rating = 4.8f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "苹果派",
                            imageUrl = "https://copyright.bdstatic.com/vcg/creative/4c192e104fb162f375077344199c114b.jpg@wm_1,k_cGljX2JqaHdhdGVyLmpwZw==",
                            cookingTime = 40,
                            calories = 420,
                            ingredients = listOf("苹果", "面粉", "黄油", "糖"),
                            description = "传统美味的苹果派",
                            category = "甜点",
                            rating = 4.6f,
                            difficulty = "困难"
                        ),
                        Recipe(
                            name = "西红柿炒蛋",
                            imageUrl = "https://ts1.tc.mm.bing.net/th/id/R-C.664fb04543c75eaa897dbad8ee716f37?rik=I4xqeJYfjrfb7Q&riu=http%3a%2f%2fcp2.douguo.net%2fupload%2fcaiku%2f3%2fe%2f2%2fyuan_3e57816522f39809b1903083c1baddb2.jpg&ehk=CyAKl%2bdCJWPKfzxQhcHD7qyQckAvJ87BcIBpP6H0PDw%3d&risl=&pid=ImgRaw&r=0",
                            cookingTime = 8,
                            calories = 180,
                            ingredients = listOf("西红柿", "鸡蛋", "葱", "盐"),
                            description = "经典家常菜，简单又美味",
                            category = "中餐",
                            rating = 4.3f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "清炒西兰花",
                            imageUrl = "https://bkimg.cdn.bcebos.com/pic/f9dcd100baa1cd11728bc54a935bdffcc3cec3fd870a",
                            cookingTime = 10,
                            calories = 120,
                            ingredients = listOf("西兰花", "蒜", "盐", "油"),
                            description = "清爽健康的西兰花",
                            category = "蔬菜",
                            rating = 4.1f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "牛肉面",
                            imageUrl = "https://qcloud.dpfile.com/pc/PxIJ-hcTVWQHwgo4EWiKi1it7Xfn-SHmtOP1wyVECPcP5RYKbIKzVIZXPjmiITWW.jpg",
                            cookingTime = 35,
                            calories = 450,
                            ingredients = listOf("牛肉", "面条", "青菜", "姜", "葱"),
                            description = "香浓牛肉面，营养丰富",
                            category = "面食",
                            rating = 4.7f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "煎饺",
                            imageUrl = "https://gips0.baidu.com/it/u=4141428966,2630281644&fm=3074&app=3074&f=JPEG?w=1080&h=1054&type=normal&func=",
                            cookingTime = 15,
                            calories = 280,
                            ingredients = listOf("饺子皮", "猪肉", "白菜", "姜"),
                            description = "金黄酥脆的煎饺",
                            category = "小吃",
                            rating = 4.4f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "水果沙拉",
                            imageUrl = "https://img1.baidu.com/it/u=2307906550,1191080399&fm=253&fmt=auto&app=120&f=JPEG?w=800&h=975",
                            cookingTime = 10,
                            calories = 160,
                            ingredients = listOf("苹果", "蓝莓", "草莓", "香蕉", "葡萄", "酸奶"),
                            description = "新鲜水果沙拉，维生素满满",
                            category = "沙拉",
                            rating = 4.2f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "红烧肉",
                            imageUrl = "https://qcloud.dpfile.com/pc/gozx53dxUuOjBJKf5pMs7iCCehyi_KZPZd7hWKi0Os-K3R5Ac8sPJZic56Lvm_q0.jpg",
                            cookingTime = 60,
                            calories = 520,
                            ingredients = listOf("五花肉", "姜", "葱", "糖", "酱油"),
                            description = "经典红烧肉，肥而不腻",
                            category = "中餐",
                            rating = 4.8f,
                            difficulty = "困难"
                        ),
                        Recipe(
                            name = "炒饭",
                            imageUrl = "https://miaobi-lite.cdn.bcebos.com/miaobi/5mao/b%2754Gr6IW/6JuL54KS6aWt55qE5YGa5rOVXzE3MzMxMTI3NDUuMTU2MDc5OA%3D%3D%27/0.png",
                            cookingTime = 15,
                            calories = 350,
                            ingredients = listOf("米饭", "鸡蛋", "胡萝卜", "豌豆", "火腿"),
                            description = "色香味俱全的炒饭",
                            category = "主食",
                            rating = 4.3f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "酸辣汤",
                            imageUrl = "https://q9.itc.cn/images01/20241024/4e0d0cbc16bc4070858475a7d262cf0e.jpeg",
                            cookingTime = 20,
                            calories = 180,
                            ingredients = listOf("豆腐", "香菇", "鸡蛋", "醋", "胡椒粉"),
                            description = "开胃酸辣汤",
                            category = "汤类",
                            rating = 4.5f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "蒸蛋",
                            imageUrl = "https://qcloud.dpfile.com/pc/ZoQL7061FshRkDxRBnnoKo_Z0Z2O7NHP81tY4ZTKyr24pKUR4-7HxwbA7VFa8fTK.jpg",
                            cookingTime = 12,
                            calories = 150,
                            ingredients = listOf("鸡蛋", "盐", "酱油"),
                            description = "滑嫩可口的蒸蛋",
                            category = "家常菜",
                            rating = 4.0f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "炸鸡翅",
                            imageUrl = "https://qcloud.dpfile.com/pc/YXe-bPHrYX3hmj7pYO6Lyi-u3YPeZvxNCPGqEWqsmTx_s19RoDoKq-qnEG-HKmy0.jpg",
                            cookingTime = 25,
                            calories = 380,
                            ingredients = listOf("鸡翅", "面粉", "鸡蛋"),
                            description = "香脆多汁的炸鸡翅",
                            category = "小吃",
                            rating = 4.6f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "蔬菜炒面",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%276Iy05a2Q55m954KS6Z2iXzE3MjkyMzY5MDAuNzc3MzQ0%27/0.png",
                            cookingTime = 18,
                            calories = 320,
                            ingredients = listOf("面条", "胡萝卜",  "青菜", "酱油"),
                            description = "健康的蔬菜炒面",
                            category = "面食",
                            rating = 4.2f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "南瓜汤",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%275aW25rK55Y2X55Oc5rGkXzE3MzAwNTE1MjAuNTk4NzY3OA%3D%3D%27/0.png",
                            cookingTime = 30,
                            calories = 200,
                            ingredients = listOf("南瓜", "洋葱", "奶油", "盐"),
                            description = "香甜浓郁的南瓜汤",
                            category = "汤类",
                            rating = 4.4f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "寿司卷",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%275a%2B/5Y%2B45Zu%2B54mHXzE3MzU3NDg1NTcuMzI5MTYzOA%3D%3D%27/0.png",
                            cookingTime = 40,
                            calories = 280,
                            ingredients = listOf("米饭", "海苔", "黄瓜", "胡萝卜", "蟹棒"),
                            description = "美味寿司卷",
                            category = "日料",
                            rating = 4.7f,
                            difficulty = "困难"
                        ),
                        Recipe(
                            name = "巧克力蛋糕",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%2754Ok6JuL57OVXzE3MzUwNjE3OTQuOTA5OTU0%27/0.png",
                            cookingTime = 50,
                            calories = 450,
                            ingredients = listOf("面粉", "鸡蛋", "巧克力", "糖", "黄油"),
                            description = "浓郁巧克力蛋糕",
                            category = "甜点",
                            rating = 4.9f,
                            difficulty = "困难"
                        ),
                        Recipe(
                            name = "意大利面",
                            imageUrl = "https://qcloud.dpfile.com/pc/hbCACTnWaKcC9e9u4dk1FZTSUDVB6I6oJr1n1CZUH9QSBlpiZ85rM5hHtJoecYS-.jpg",
                            cookingTime = 25,
                            calories = 380,
                            ingredients = listOf("意大利面", "番茄", "牛肉末", "洋葱", "芝士"),
                            description = "经典意大利面",
                            category = "西餐",
                            rating = 4.6f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "蔬菜卷",
                            imageUrl = "https://qcloud.dpfile.com/pc/YFS7Uz3tdBeXSHB1glghJupMMj5y_FasN9zh-zZ4z-KBfe-4FQWzHbF75cwE-Xsc.jpg",
                            cookingTime = 15,
                            calories = 160,
                            ingredients = listOf("生菜", "胡萝卜", "黄瓜", "鸡肉", "酱料"),
                            description = "健康蔬菜卷",
                            category = "轻食",
                            rating = 4.3f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "咖喱饭",
                            imageUrl = "https://bkimg.cdn.bcebos.com/pic/9213b07eca8065380cd7607dc996b644ad3459822403",
                            cookingTime = 35,
                            calories = 420,
                            ingredients = listOf("米饭", "鸡肉", "胡萝卜", "土豆", "咖喱块"),
                            description = "香浓咖喱饭",
                            category = "主食",
                            rating = 4.7f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "凉拌黄瓜",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%275YeJ5ouM6buE55Oc5Zu%2B54mHXzE3MzUwNjI5OTIuNTk1ODY0%27/0.png",
                            cookingTime = 5,
                            calories = 80,
                            ingredients = listOf("黄瓜", "蒜", "醋", "酱油", "香油"),
                            description = "清爽凉拌黄瓜",
                            category = "凉菜",
                            rating = 4.1f,
                            difficulty = "简单"
                        ),
                        Recipe(
                            name = "煎牛排",
                            imageUrl = "https://qcloud.dpfile.com/pc/ASKBF6G_IoA1I0S6R3P2iiBeEafZdEttBERAh5ktsj5t8HHXZBGD9g9R-cfMaIzW.jpg",
                            cookingTime = 20,
                            calories = 480,
                            ingredients = listOf("牛排", "黄油", "蒜", "盐", "黑胡椒"),
                            description = "嫩滑多汁的煎牛排",
                            category = "西餐",
                            rating = 4.8f,
                            difficulty = "中等"
                        ),
                        Recipe(
                            name = "香菇鸡",
                            imageUrl = "https://miaobi-lite.bj.bcebos.com/miaobi/5mao/b%275YeP6ISC6bih6IW/6IKJ5LiD56eN5YGa5rOVXzE3MzQ2NDAyMzYuNzIxMTE1NA%3D%3D%27/0.png",
                            cookingTime = 45,
                            calories = 220,
                            ingredients = listOf("鸡肉", "香菇", "姜", "葱", "盐"),
                            description = "营养滋补的香菇鸡",
                            category = "汤类",
                            rating = 4.5f,
                            difficulty = "中等"
                        )


                    )
                    sampleRecipes.forEach { recipeDao.insertRecipe(it) }
                    
                    // 添加示例购物清单
                    val shoppingItemDao = shoppingItemDaoProvider.get()
                    val sampleShoppingItems = listOf(
                        ShoppingItem(name = "生菜", quantity = "2颗"),
                        ShoppingItem(name = "面包片", quantity = "1袋"),
                        ShoppingItem(name = "橄榄油", quantity = "1瓶")
                    )
                    sampleShoppingItems.forEach { shoppingItemDao.insertShoppingItem(it) }
                }
            }
        })
        .build()
    }
    
    @Provides
    fun provideFoodItemDao(database: KitchenPalDatabase): FoodItemDao {
        return database.foodItemDao()
    }
    
    @Provides
    fun provideRecipeDao(database: KitchenPalDatabase): RecipeDao {
        return database.recipeDao()
    }
    
    @Provides
    fun provideShoppingItemDao(database: KitchenPalDatabase): ShoppingItemDao {
        return database.shoppingItemDao()
    }
    
    @Provides
    fun provideUserDao(database: KitchenPalDatabase): UserDao {
        return database.userDao()
    }
}
