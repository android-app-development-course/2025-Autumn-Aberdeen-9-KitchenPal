package com.example.kitchenpal

import android.app.Application
import com.example.kitchenpal.di.DataInitializer
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class KitchenPalApplication : Application() {
    
    @Inject
    lateinit var dataInitializer: DataInitializer
    
    override fun onCreate() {
        super.onCreate()
        dataInitializer.initializeData()
    }
}
