package com.example.kitchenpal.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.kitchenpal.ui.components.ShoppingListItem
import com.example.kitchenpal.ui.theme.*
import com.example.kitchenpal.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var newItemName by remember { mutableStateOf("") }
    var newItemQuantity by remember { mutableStateOf("") }
    var showPersonalInfoDialog by remember { mutableStateOf(false) }
    var showNotificationDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    
    // Add Shopping Item Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { 
                showAddDialog = false
                newItemName = ""
                newItemQuantity = ""
            },
            title = { Text("添加购物项") },
            text = {
                Column {
                    OutlinedTextField(
                        value = newItemName,
                        onValueChange = { newItemName = it },
                        label = { Text("名称") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newItemQuantity,
                        onValueChange = { newItemQuantity = it },
                        label = { Text("数量") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newItemName.isNotBlank()) {
                            viewModel.addShoppingItem(newItemName, newItemQuantity)
                            showAddDialog = false
                            newItemName = ""
                            newItemQuantity = ""
                        }
                    }
                ) {
                    Text("添加", color = PrimaryGreen)
                }
            },
            dismissButton = {
                TextButton(onClick = { 
                    showAddDialog = false
                    newItemName = ""
                    newItemQuantity = ""
                }) {
                    Text("取消", color = TextSecondary)
                }
            }
        )
    }
    
    // Personal Info Dialog
    if (showPersonalInfoDialog) {
        AlertDialog(
            onDismissRequest = { showPersonalInfoDialog = false },
            title = { Text("个人信息") },
            text = {
                Column {
                    Text("用户名：厨房小助手用户", color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("邮箱：user@kitchenpal.com", color = TextSecondary)
                }
            },
            confirmButton = {
                TextButton(onClick = { showPersonalInfoDialog = false }) {
                    Text("确定", color = PrimaryGreen)
                }
            }
        )
    }
    
    // Notification Dialog
    if (showNotificationDialog) {
        AlertDialog(
            onDismissRequest = { showNotificationDialog = false },
            title = { Text("通知设置") },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("过期提醒", color = TextPrimary)
                        Switch(
                            checked = true,
                            onCheckedChange = {},
                            colors = SwitchDefaults.colors(checkedTrackColor = PrimaryGreen)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("菜谱推荐", color = TextPrimary)
                        Switch(
                            checked = true,
                            onCheckedChange = {},
                            colors = SwitchDefaults.colors(checkedTrackColor = PrimaryGreen)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotificationDialog = false }) {
                    Text("确定", color = PrimaryGreen)
                }
            }
        )
    }
    
    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("隐私设置") },
            text = { Text("您的数据仅存储在本地设备上，我们不会收集任何个人信息。", color = TextSecondary) },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("确定", color = PrimaryGreen)
                }
            }
        )
    }
    
    // Help Dialog
    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("帮助与反馈") },
            text = {
                Column {
                    Text("如有问题或建议，请联系：", color = TextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("support@kitchenpal.com", color = PrimaryGreen)
                }
            },
            confirmButton = {
                TextButton(onClick = { showHelpDialog = false }) {
                    Text("确定", color = PrimaryGreen)
                }
            }
        )
    }
    
    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .statusBarsPadding()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(15.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }
            
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "我的",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryGreenDark
                    )
                    IconButton(onClick = { showNotificationDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "设置",
                            tint = PrimaryGreen,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }
            
            // Shopping List Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "购物清单",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryGreenDark
                    )
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "添加",
                            tint = PrimaryGreen
                        )
                    }
                }
            }
            
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp)) {
                        if (uiState.shoppingItems.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(30.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = "购物清单为空", color = TextSecondary)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    TextButton(onClick = { showAddDialog = true }) {
                                        Text("点击添加", color = PrimaryGreen)
                                    }
                                }
                            }
                        } else {
                            uiState.shoppingItems.forEach { item ->
                                ShoppingListItem(
                                    item = item,
                                    onCheckedChange = { viewModel.toggleShoppingItem(item) },
                                    onDelete = { viewModel.deleteShoppingItem(item) }
                                )
                                if (item != uiState.shoppingItems.last()) {
                                    HorizontalDivider(color = DividerColor)
                                }
                            }
                        }
                    }
                }
            }
            
            // Settings Section
            item {
                Spacer(modifier = Modifier.height(15.dp))
                Text(
                    text = "个人设置",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryGreenDark
                )
            }
            
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column {
                        SettingsItem(
                            icon = Icons.Default.Person,
                            title = "个人信息",
                            onClick = { showPersonalInfoDialog = true }
                        )
                        HorizontalDivider(color = DividerColor)
                        SettingsItem(
                            icon = Icons.Default.Notifications,
                            title = "通知设置",
                            onClick = { showNotificationDialog = true }
                        )
                        HorizontalDivider(color = DividerColor)
                        SettingsItem(
                            icon = Icons.Default.Security,
                            title = "隐私设置",
                            onClick = { showPrivacyDialog = true }
                        )
                        HorizontalDivider(color = DividerColor)
                        SettingsItem(
                            icon = Icons.Default.Help,
                            title = "帮助与反馈",
                            onClick = { showHelpDialog = true }
                        )
                    }
                }
            }
            
            // Bottom spacing
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
private fun SettingsItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = PrimaryGreen,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(15.dp))
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            fontSize = 14.sp,
            color = TextPrimary
        )
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = IconGray
        )
    }
}
