package com.example.kitchenpal.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.Recipe
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.data.repository.FoodRepository
import com.example.kitchenpal.data.repository.RecipeRepository
import com.example.kitchenpal.data.repository.ShoppingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RecipeWithMissing(
    val recipe: Recipe,
    val missingIngredients: List<String>,
    val matchScore: Float = 0f
)

data class RecipeUiState(
    val recipes: List<RecipeWithMissing> = emptyList(),
    val isLoading: Boolean = true,
    val showPlanAddedMessage: Boolean = false,
    val planAddedRecipeName: String = "",
    val addedShoppingItems: List<String> = emptyList()
)

@HiltViewModel
class RecipeViewModel @Inject constructor(
    private val recipeRepository: RecipeRepository,
    private val foodRepository: FoodRepository,
    private val shoppingRepository: ShoppingRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(RecipeUiState())
    val uiState: StateFlow<RecipeUiState> = _uiState.asStateFlow()

    init {
        loadRecipes()
    }

    private fun loadRecipes() {
        viewModelScope.launch {
            combine(
                recipeRepository.getAllRecipes(),
                foodRepository.getAllFoodItems()
            ) { recipes, inventory ->
                // 计算每个食谱的匹配度并排序
                recipes.map { recipe ->
                    val missingIngredients =
                        recipeRepository.getMissingIngredients(recipe, inventory)
                    val matchScore = calculateMatchScore(recipe, inventory, missingIngredients)
                    RecipeWithMissing(
                        recipe = recipe,
                        missingIngredients = missingIngredients,
                        matchScore = matchScore
                    )
                }
                    .sortedByDescending { it.matchScore } // 按匹配度降序排序
            }.collect { recipesWithMissing ->
                _uiState.value = RecipeUiState(
                    recipes = recipesWithMissing,
                    isLoading = false
                )
            }
        }
    }

    private fun calculateMatchScore(
        recipe: Recipe,
        inventory: List<FoodItem>,
        missingIngredients: List<String>
    ): Float {
        if (recipe.ingredients.isEmpty()) return 0f

        val totalIngredients = recipe.ingredients.size
        val missingCount = missingIngredients.size

        // 基础匹配度：根据缺失食材比例
        val baseScore = 1f - (missingCount.toFloat() / totalIngredients.toFloat())

        // 额外加分项：
        var bonusScore = 0f

        // 1. 如果没有缺失食材，满分
        if (missingCount == 0) {
            bonusScore += 0.2f
        }

        // 2. 如果食谱难度简单，加分
        when (recipe.difficulty) {
            "简单" -> bonusScore += 0.15f
            "中等" -> bonusScore += 0.1f
            "困难" -> bonusScore += 0.05f
        }

        // 3. 如果烹饪时间短，加分
        if (recipe.cookingTime <= 15) {
            bonusScore += 0.1f
        } else if (recipe.cookingTime <= 30) {
            bonusScore += 0.05f
        }

        // 4. 如果卡路里较低，加分
        if (recipe.calories <= 300) {
            bonusScore += 0.1f
        }

        // 计算最终分数，确保不超过1.0
        val finalScore = (baseScore + bonusScore).coerceAtMost(1.0f)

        return finalScore
    }

    fun addRecipeToPlan(recipe: Recipe) {
        viewModelScope.launch {
            // 获取当前库存和缺失食材
            val inventory = foodRepository.getAllFoodItems().firstOrNull() ?: emptyList()
            val missingIngredients = recipeRepository.getMissingIngredients(recipe, inventory)

            // 将缺失食材添加到购物清单
            val addedItems = mutableListOf<String>()
            missingIngredients.forEach { ingredient ->
                // 使用新的 Repository 方法检查是否已存在
                val alreadyExists = shoppingRepository.isItemAlreadyExists(ingredient)

                if (!alreadyExists) {
                    shoppingRepository.addShoppingItem(
                        ShoppingItem(
                            name = ingredient,
                            quantity = getDefaultQuantity(ingredient), // 根据食材类型设置默认数量
                            isChecked = false
                        )
                    )
                    addedItems.add(ingredient)
                }
            }

            _uiState.value = _uiState.value.copy(
                showPlanAddedMessage = true,
                planAddedRecipeName = recipe.name,
                addedShoppingItems = addedItems
            )
        }
    }

    private fun getDefaultQuantity(ingredient: String): String {
        return when {
            ingredient.contains("酱") -> "1瓶"
            ingredient.contains("油") -> "1瓶"
            ingredient.contains("盐") -> "1袋"
            ingredient.contains("糖") -> "1袋"
            ingredient.contains("醋") -> "1瓶"
            ingredient.contains("奶") -> "1L"
            ingredient.contains("肉") -> "500g"
            ingredient.contains("菜") -> "1颗"
            ingredient.contains("胡萝卜") -> "3根"
            ingredient.contains("苹果") -> "3个"
            ingredient.contains("面包") -> "1袋"
            ingredient.contains("鸡蛋") -> "6个"
            ingredient.contains("米") -> "1kg"
            ingredient.contains("面") -> "500g"
            ingredient.contains("豆") -> "300g"
            else -> "适量"
        }
    }
    fun dismissPlanAddedMessage() {
        _uiState.value = _uiState.value.copy(
            showPlanAddedMessage = false,
            planAddedRecipeName = "",
            addedShoppingItems = emptyList()
        )
    }
}
