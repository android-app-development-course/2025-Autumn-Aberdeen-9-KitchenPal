package com.example.kitchenpal.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.kitchenpal.ui.screens.*

@Composable
fun NavGraph(
    navController: NavHostController,
    startDestination: String = Screen.Login.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Login.route) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }
        
        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToManualInput = { navController.navigate(Screen.ManualInput.route) },
                onNavigateToInventory = { navController.navigate(Screen.Inventory.route) }
            )
        }
        
        composable(Screen.Inventory.route) {
            InventoryScreen(
                onNavigateToEdit = { foodItemId ->
                    navController.navigate(Screen.EditFoodItem.createRoute(foodItemId))
                },
                onNavigateToAdd = { navController.navigate(Screen.ManualInput.route) }
            )
        }
        
        composable(Screen.Recipes.route) {
            RecipesScreen(
                onNavigateToDetail = { recipeId ->
                    navController.navigate(Screen.RecipeDetail.createRoute(recipeId))
                }
            )
        }
        
        composable(
            route = Screen.RecipeDetail.route,
            arguments = listOf(navArgument("recipeId") { type = NavType.LongType })
        ) { backStackEntry ->
            val recipeId = backStackEntry.arguments?.getLong("recipeId") ?: 0L
            RecipeDetailScreen(
                recipeId = recipeId,
                onBack = { navController.popBackStack() }
            )
        }
        
        composable(Screen.Profile.route) {
            ProfileScreen()
        }
        
        composable(Screen.ManualInput.route) {
            ManualInputScreen(
                onClose = { navController.popBackStack() },
                onSaveSuccess = { navController.popBackStack() }
            )
        }
        
        composable(
            route = Screen.EditFoodItem.route,
            arguments = listOf(navArgument("foodItemId") { type = NavType.LongType })
        ) { backStackEntry ->
            val foodItemId = backStackEntry.arguments?.getLong("foodItemId") ?: 0L
            EditFoodItemScreen(
                foodItemId = foodItemId,
                onClose = { navController.popBackStack() },
                onSaveSuccess = { navController.popBackStack() }
            )
        }
    }
}
