package com.example.kitchenpal.data.dao

import androidx.room.*
import com.example.kitchenpal.data.model.ShoppingItem
import kotlinx.coroutines.flow.Flow

@Dao
interface ShoppingItemDao {
    @Query("SELECT * FROM shopping_items ORDER BY createdAt DESC")
    fun getAllShoppingItems(): Flow<List<ShoppingItem>>

    @Query("SELECT * FROM shopping_items WHERE id = :id")
    suspend fun getShoppingItemById(id: Long): ShoppingItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingItem(item: ShoppingItem): Long

    @Update
    suspend fun updateShoppingItem(item: ShoppingItem)

    @Delete
    suspend fun deleteShoppingItem(item: ShoppingItem)

    @Query("DELETE FROM shopping_items")
    suspend fun deleteAllShoppingItems()

    // 新增方法：根据名称获取购物清单项
    @Query("SELECT * FROM shopping_items WHERE name = :name")
    suspend fun getShoppingItemByName(name: String): ShoppingItem?

    // 新增方法：删除已勾选的项
    @Query("DELETE FROM shopping_items WHERE isChecked = 1")
    suspend fun deleteCheckedItems()

    // 新增方法：检查是否存在相同名称的未勾选项
    @Query("SELECT COUNT(*) FROM shopping_items WHERE name = :name AND isChecked = 0")
    suspend fun countUncheckedByName(name: String): Int
}