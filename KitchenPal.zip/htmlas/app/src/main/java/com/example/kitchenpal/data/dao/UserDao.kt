package com.example.kitchenpal.data.dao

import androidx.room.*
import com.example.kitchenpal.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = 1")
    fun getUser(): Flow<User?>
    
    @Query("SELECT * FROM users WHERE id = 1")
    suspend fun getUserSync(): User?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)
    
    @Update
    suspend fun updateUser(user: User)
}
