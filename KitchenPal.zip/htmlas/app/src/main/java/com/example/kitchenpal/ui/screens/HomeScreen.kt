package com.example.kitchenpal.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.ui.components.FoodItemCard
import com.example.kitchenpal.ui.components.InventoryCategoryCard
import com.example.kitchenpal.ui.theme.*
import com.example.kitchenpal.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    onNavigateToManualInput: () -> Unit,
    onNavigateToInventory: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "我的厨房",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreenDark
                        )
                        Text(
                            text = "管理你的食材库存",
                            fontSize = 14.sp,
                            color = TextSecondary
                        )
                    }
                    IconButton(onClick = { /* TODO: 通知 */ }) {
                        Badge(
                            containerColor = if (uiState.expiringItems.isNotEmpty()) StatusCritical else Color.Transparent
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "通知",
                                modifier = Modifier.size(28.dp),
                                tint = PrimaryGreen
                            )
                        }
                    }
                }
            }
            
            // 库存概览卡片
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PrimaryGreen)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatItem(
                            value = uiState.categoryCounts.sumOf { it.count }.toString(),
                            label = "总食材"
                        )
                        StatItem(
                            value = uiState.expiringItems.size.toString(),
                            label = "即将过期"
                        )
                        StatItem(
                            value = uiState.categoryCounts.count { it.count > 0 }.toString(),
                            label = "分类"
                        )
                    }
                }
            }
            
            // Category Cards Grid
            item {
                Text(
                    text = "食材分类",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryGreenDark
                )
            }
            
            item {
                val mainCategories = listOf(
                    FoodCategory.VEGETABLE,
                    FoodCategory.FRUIT,
                    FoodCategory.MEAT,
                    FoodCategory.BEVERAGE
                )
                
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(220.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(mainCategories) { category ->
                        val count = uiState.categoryCounts.find { it.category == category }?.count ?: 0
                        InventoryCategoryCard(
                            category = category,
                            itemCount = count,
                            onClick = onNavigateToInventory
                        )
                    }
                }
            }
            
            // Expiring Soon Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "即将过期",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryGreenDark
                    )
                    if (uiState.expiringItems.isNotEmpty()) {
                        TextButton(onClick = onNavigateToInventory) {
                            Text(
                                text = "查看全部",
                                color = PrimaryGreen
                            )
                        }
                    }
                }
            }
            
            if (uiState.expiringItems.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = StatusFresh
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "太棒了！",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = PrimaryGreenDark
                            )
                            Text(
                                text = "暂无即将过期的食材",
                                color = TextSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else {
                items(uiState.expiringItems.take(3)) { item ->
                    FoodItemCard(foodItem = item)
                }
            }
            
            // Bottom spacing for navigation bar
            item {
                Spacer(modifier = Modifier.height(140.dp))
            }
        }
        
        // FAB
        ExtendedFloatingActionButton(
            onClick = onNavigateToManualInput,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 100.dp),
            containerColor = PrimaryGreen,
            contentColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "添加食材",
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun StatItem(
    value: String,
    label: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color.White.copy(alpha = 0.8f)
        )
    }
}
