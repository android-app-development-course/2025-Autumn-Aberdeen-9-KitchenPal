package com.example.kitchenpal.property

import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.element
import io.kotest.property.checkAll

/**
 * **Feature: kitchen-pal-app, Property 9: Navigation State Consistency**
 * **Validates: Requirements 9.2, 9.3**
 * 
 * For any navigation action to a main page, the bottom navigation bar's 
 * active item should match the current page route.
 */
class NavigationStatePropertyTest : FunSpec({
    
    data class NavItem(val route: String, val index: Int)
    
    val mainRoutes = listOf(
        NavItem("home", 0),
        NavItem("inventory", 1),
        NavItem("recipes", 2),
        NavItem("profile", 3)
    )
    
    fun getActiveNavIndex(currentRoute: String): Int {
        return when (currentRoute) {
            "home" -> 0
            "inventory" -> 1
            "recipes" -> 2
            "profile" -> 3
            else -> 0 // Default to home
        }
    }
    
    fun isMainRoute(route: String): Boolean {
        return route in listOf("home", "inventory", "recipes", "profile")
    }
    
    test("active nav index matches current route for all main pages") {
        checkAll(100, Arb.element(mainRoutes)) { navItem ->
            val activeIndex = getActiveNavIndex(navItem.route)
            activeIndex shouldBe navItem.index
        }
    }
    
    test("navigating to home sets index 0") {
        getActiveNavIndex("home") shouldBe 0
    }
    
    test("navigating to inventory sets index 1") {
        getActiveNavIndex("inventory") shouldBe 1
    }
    
    test("navigating to recipes sets index 2") {
        getActiveNavIndex("recipes") shouldBe 2
    }
    
    test("navigating to profile sets index 3") {
        getActiveNavIndex("profile") shouldBe 3
    }
    
    test("non-main routes default to home index") {
        val nonMainRoutes = listOf("login", "scan", "manual_input", "settings")
        nonMainRoutes.forEach { route ->
            getActiveNavIndex(route) shouldBe 0
        }
    }
    
    test("all main routes are recognized as main routes") {
        mainRoutes.forEach { navItem ->
            isMainRoute(navItem.route) shouldBe true
        }
    }
    
    test("non-main routes are not recognized as main routes") {
        val nonMainRoutes = listOf("login", "scan", "manual_input")
        nonMainRoutes.forEach { route ->
            isMainRoute(route) shouldBe false
        }
    }
})
