package com.example.kitchenpal.property

import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.StorageLocation
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeEmpty
import io.kotest.matchers.collections.shouldBeSortedWith
import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll
import java.time.LocalDate

/**
 * **Feature: kitchen-pal-app, Property 3: Expiring Items Filter**
 * **Validates: Requirements 2.4**
 * 
 * For any set of food items, the "expiring soon" list should contain exactly 
 * those items whose expiry date is within 3 days of the current date, 
 * sorted by expiry date ascending.
 */
class ExpiringItemsFilterPropertyTest : FunSpec({
    
    fun filterExpiringItems(items: List<FoodItem>, withinDays: Int, currentDate: LocalDate): List<FoodItem> {
        val targetDate = currentDate.plusDays(withinDays.toLong())
        return items.filter { it.expiryDate <= targetDate }
            .sortedBy { it.expiryDate }
    }
    
    val foodItemArb = arbitrary {
        FoodItem(
            id = Arb.long(1, 1000).bind(),
            name = Arb.string(5..20).bind(),
            category = Arb.enum<FoodCategory>().bind(),
            quantity = Arb.string(1..10).bind(),
            expiryDate = Arb.localDate(
                minDate = LocalDate.now().minusDays(10),
                maxDate = LocalDate.now().plusDays(30)
            ).bind(),
            storageLocation = Arb.enum<StorageLocation>().bind()
        )
    }
    
    test("expiring items filter returns only items within specified days") {
        checkAll(100, Arb.list(foodItemArb, 0..20)) { items ->
            val currentDate = LocalDate.now()
            val withinDays = 3
            val targetDate = currentDate.plusDays(withinDays.toLong())
            
            val filtered = filterExpiringItems(items, withinDays, currentDate)
            
            // All filtered items should have expiry date <= target date
            filtered.forEach { item ->
                (item.expiryDate <= targetDate) shouldBe true
            }
            
            // All items not in filtered should have expiry date > target date
            val notFiltered = items.filter { it !in filtered }
            notFiltered.forEach { item ->
                (item.expiryDate > targetDate) shouldBe true
            }
        }
    }
    
    test("expiring items filter returns items sorted by expiry date ascending") {
        checkAll(100, Arb.list(foodItemArb, 0..20)) { items ->
            val currentDate = LocalDate.now()
            val filtered = filterExpiringItems(items, 3, currentDate)
            
            filtered shouldBeSortedWith compareBy { it.expiryDate }
        }
    }
    
    test("empty list returns empty filtered list") {
        val filtered = filterExpiringItems(emptyList(), 3, LocalDate.now())
        filtered.shouldBeEmpty()
    }
    
    test("filter with 0 days returns only items expiring today or earlier") {
        checkAll(100, Arb.list(foodItemArb, 0..20)) { items ->
            val currentDate = LocalDate.now()
            val filtered = filterExpiringItems(items, 0, currentDate)
            
            filtered.forEach { item ->
                (item.expiryDate <= currentDate) shouldBe true
            }
        }
    }
})
