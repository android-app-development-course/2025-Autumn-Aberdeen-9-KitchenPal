package com.example.kitchenpal.property

import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.ShoppingItem
import com.example.kitchenpal.data.model.StorageLocation
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll
import java.time.LocalDate

/**
 * **Feature: kitchen-pal-app, Property 5: Food Item Persistence Round-Trip**
 * **Validates: Requirements 4.2, 10.1**
 * 
 * For any valid food item data, adding the item to the inventory and then 
 * querying the inventory should return an item with identical name, category, 
 * quantity, expiry date, and storage location.
 */
class FoodItemPersistencePropertyTest : FunSpec({
    
    // Simulated in-memory storage for testing
    class InMemoryFoodStorage {
        private val items = mutableMapOf<Long, FoodItem>()
        private var nextId = 1L
        
        fun insert(item: FoodItem): Long {
            val id = nextId++
            val itemWithId = item.copy(id = id)
            items[id] = itemWithId
            return id
        }
        
        fun getById(id: Long): FoodItem? = items[id]
        
        fun clear() {
            items.clear()
            nextId = 1L
        }
    }
    
    val storage = InMemoryFoodStorage()
    
    val foodItemArb = arbitrary {
        FoodItem(
            id = 0, // Will be assigned by storage
            name = Arb.string(1..50).bind(),
            category = Arb.enum<FoodCategory>().bind(),
            quantity = Arb.string(1..20).bind(),
            expiryDate = Arb.localDate(
                minDate = LocalDate.now(),
                maxDate = LocalDate.now().plusYears(2)
            ).bind(),
            storageLocation = Arb.enum<StorageLocation>().bind()
        )
    }
    
    beforeEach {
        storage.clear()
    }
    
    test("inserted food item can be retrieved with same properties") {
        checkAll(100, foodItemArb) { item ->
            storage.clear()
            val id = storage.insert(item)
            val retrieved = storage.getById(id)
            
            retrieved shouldBe item.copy(id = id)
            retrieved?.name shouldBe item.name
            retrieved?.category shouldBe item.category
            retrieved?.quantity shouldBe item.quantity
            retrieved?.expiryDate shouldBe item.expiryDate
            retrieved?.storageLocation shouldBe item.storageLocation
        }
    }
    
    test("multiple items can be stored and retrieved independently") {
        checkAll(50, Arb.list(foodItemArb, 2..10)) { items ->
            storage.clear()
            val ids = items.map { storage.insert(it) }
            
            items.forEachIndexed { index, originalItem ->
                val retrieved = storage.getById(ids[index])
                retrieved?.name shouldBe originalItem.name
                retrieved?.category shouldBe originalItem.category
                retrieved?.quantity shouldBe originalItem.quantity
                retrieved?.expiryDate shouldBe originalItem.expiryDate
                retrieved?.storageLocation shouldBe originalItem.storageLocation
            }
        }
    }
})

/**
 * **Feature: kitchen-pal-app, Property 10: Shopping Item Persistence Round-Trip**
 * **Validates: Requirements 10.3**
 * 
 * For any shopping item modification (checked state change), querying the item 
 * after modification should return the updated state.
 */
class ShoppingItemPersistencePropertyTest : FunSpec({
    
    // Simulated in-memory storage for testing
    class InMemoryShoppingStorage {
        private val items = mutableMapOf<Long, ShoppingItem>()
        private var nextId = 1L
        
        fun insert(item: ShoppingItem): Long {
            val id = nextId++
            val itemWithId = item.copy(id = id)
            items[id] = itemWithId
            return id
        }
        
        fun update(item: ShoppingItem) {
            if (items.containsKey(item.id)) {
                items[item.id] = item
            }
        }
        
        fun getById(id: Long): ShoppingItem? = items[id]
        
        fun clear() {
            items.clear()
            nextId = 1L
        }
    }
    
    val storage = InMemoryShoppingStorage()
    
    val shoppingItemArb = arbitrary {
        ShoppingItem(
            id = 0, // Will be assigned by storage
            name = Arb.string(1..50).bind(),
            quantity = Arb.string(1..20).bind(),
            isChecked = Arb.boolean().bind()
        )
    }
    
    beforeEach {
        storage.clear()
    }
    
    test("inserted shopping item can be retrieved with same properties") {
        checkAll(100, shoppingItemArb) { item ->
            storage.clear()
            val id = storage.insert(item)
            val retrieved = storage.getById(id)
            
            retrieved shouldBe item.copy(id = id)
            retrieved?.name shouldBe item.name
            retrieved?.quantity shouldBe item.quantity
            retrieved?.isChecked shouldBe item.isChecked
        }
    }
    
    test("updated checked state is persisted correctly") {
        checkAll(100, shoppingItemArb) { item ->
            storage.clear()
            val id = storage.insert(item)
            
            // Toggle the checked state
            val retrieved = storage.getById(id)!!
            val updated = retrieved.copy(isChecked = !retrieved.isChecked)
            storage.update(updated)
            
            val afterUpdate = storage.getById(id)
            afterUpdate?.isChecked shouldBe !item.isChecked
        }
    }
    
    test("multiple updates preserve latest state") {
        checkAll(50, shoppingItemArb, Arb.int(1..5)) { item, toggleCount ->
            storage.clear()
            val id = storage.insert(item)
            
            var currentChecked = item.isChecked
            repeat(toggleCount) {
                currentChecked = !currentChecked
                val current = storage.getById(id)!!
                storage.update(current.copy(isChecked = currentChecked))
            }
            
            val final = storage.getById(id)
            final?.isChecked shouldBe currentChecked
        }
    }
})
