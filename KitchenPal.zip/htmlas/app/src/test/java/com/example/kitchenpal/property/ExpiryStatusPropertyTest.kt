package com.example.kitchenpal.property

import com.example.kitchenpal.data.model.ExpiryStatus
import com.example.kitchenpal.util.calculateExpiryStatus
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.int
import io.kotest.property.arbitrary.localDate
import io.kotest.property.checkAll
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * **Feature: kitchen-pal-app, Property 4: Expiry Status Calculation**
 * **Validates: Requirements 3.2**
 * 
 * For any food item and current date, the expiry status should be:
 * - CRITICAL if expiryDate <= currentDate
 * - WARNING if expiryDate is within 1-3 days from currentDate
 * - NORMAL if expiryDate is more than 3 days from currentDate
 */
class ExpiryStatusPropertyTest : FunSpec({
    
    test("expiry status calculation is correct for all date combinations") {
        checkAll(100, Arb.localDate(), Arb.localDate()) { currentDate, expiryDate ->
            val daysDiff = ChronoUnit.DAYS.between(currentDate, expiryDate)
            val expectedStatus = when {
                daysDiff <= 0 -> ExpiryStatus.CRITICAL
                daysDiff <= 3 -> ExpiryStatus.WARNING
                else -> ExpiryStatus.NORMAL
            }
            calculateExpiryStatus(expiryDate, currentDate) shouldBe expectedStatus
        }
    }
    
    test("items expiring today should be CRITICAL") {
        val today = LocalDate.now()
        calculateExpiryStatus(today, today) shouldBe ExpiryStatus.CRITICAL
    }
    
    test("items expired in the past should be CRITICAL") {
        checkAll(100, Arb.int(1, 365)) { daysAgo ->
            val today = LocalDate.now()
            val expiredDate = today.minusDays(daysAgo.toLong())
            calculateExpiryStatus(expiredDate, today) shouldBe ExpiryStatus.CRITICAL
        }
    }
    
    test("items expiring within 1-3 days should be WARNING") {
        checkAll(100, Arb.int(1, 3)) { daysUntilExpiry ->
            val today = LocalDate.now()
            val expiryDate = today.plusDays(daysUntilExpiry.toLong())
            calculateExpiryStatus(expiryDate, today) shouldBe ExpiryStatus.WARNING
        }
    }
    
    test("items expiring in more than 3 days should be NORMAL") {
        checkAll(100, Arb.int(4, 365)) { daysUntilExpiry ->
            val today = LocalDate.now()
            val expiryDate = today.plusDays(daysUntilExpiry.toLong())
            calculateExpiryStatus(expiryDate, today) shouldBe ExpiryStatus.NORMAL
        }
    }
})
