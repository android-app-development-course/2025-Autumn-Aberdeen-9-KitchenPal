package com.example.kitchenpal.property

import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.Recipe
import com.example.kitchenpal.data.model.StorageLocation
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.collections.shouldBeEmpty
import io.kotest.matchers.collections.shouldContainExactlyInAnyOrder
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll
import java.time.LocalDate

/**
 * **Feature: kitchen-pal-app, Property 6: Missing Ingredients Calculation**
 * **Validates: Requirements 6.2**
 * 
 * For any recipe and inventory state, the missing ingredients list should 
 * contain exactly those ingredients from the recipe that are not present 
 * in the inventory.
 */
class MissingIngredientsPropertyTest : FunSpec({
    
    fun getMissingIngredients(recipe: Recipe, inventory: List<FoodItem>): List<String> {
        val inventoryNames = inventory.map { it.name.lowercase() }.toSet()
        return recipe.ingredients.filter { ingredient ->
            !inventoryNames.any { inventoryName ->
                inventoryName.contains(ingredient.lowercase()) || 
                ingredient.lowercase().contains(inventoryName)
            }
        }
    }
    
    val ingredientArb = Arb.string(3..15)
    
    val recipeArb = arbitrary {
        Recipe(
            id = Arb.long(1, 1000).bind(),
            name = Arb.string(5..20).bind(),
            cookingTime = Arb.int(5..120).bind(),
            calories = Arb.int(50..1000).bind(),
            ingredients = Arb.list(ingredientArb, 1..10).bind()
        )
    }
    
    val foodItemArb = arbitrary {
        FoodItem(
            id = Arb.long(1, 1000).bind(),
            name = Arb.string(3..15).bind(),
            category = Arb.enum<FoodCategory>().bind(),
            quantity = Arb.string(1..10).bind(),
            expiryDate = Arb.localDate(
                minDate = LocalDate.now(),
                maxDate = LocalDate.now().plusDays(30)
            ).bind(),
            storageLocation = Arb.enum<StorageLocation>().bind()
        )
    }
    
    test("missing ingredients are exactly those not in inventory") {
        checkAll(100, recipeArb, Arb.list(foodItemArb, 0..20)) { recipe, inventory ->
            val missing = getMissingIngredients(recipe, inventory)
            val inventoryNames = inventory.map { it.name.lowercase() }.toSet()
            
            // All missing ingredients should not be in inventory
            missing.forEach { ingredient ->
                val isInInventory = inventoryNames.any { inventoryName ->
                    inventoryName.contains(ingredient.lowercase()) || 
                    ingredient.lowercase().contains(inventoryName)
                }
                isInInventory shouldBe false
            }
        }
    }
    
    test("empty inventory means all ingredients are missing") {
        checkAll(100, recipeArb) { recipe ->
            val missing = getMissingIngredients(recipe, emptyList())
            missing shouldContainExactlyInAnyOrder recipe.ingredients
        }
    }
    
    test("recipe with no ingredients has no missing ingredients") {
        val emptyRecipe = Recipe(
            id = 1,
            name = "Empty Recipe",
            cookingTime = 10,
            calories = 100,
            ingredients = emptyList()
        )
        
        checkAll(100, Arb.list(foodItemArb, 0..20)) { inventory ->
            val missing = getMissingIngredients(emptyRecipe, inventory)
            missing.shouldBeEmpty()
        }
    }
    
    test("when all ingredients are in inventory, missing list is empty") {
        val recipe = Recipe(
            id = 1,
            name = "Test Recipe",
            cookingTime = 10,
            calories = 100,
            ingredients = listOf("Apple", "Banana", "Carrot")
        )
        
        val inventory = listOf(
            FoodItem(1, "Apple", FoodCategory.FRUIT, "2", LocalDate.now().plusDays(5), StorageLocation.COUNTER),
            FoodItem(2, "Banana", FoodCategory.FRUIT, "3", LocalDate.now().plusDays(3), StorageLocation.COUNTER),
            FoodItem(3, "Carrot", FoodCategory.VEGETABLE, "5", LocalDate.now().plusDays(7), StorageLocation.REFRIGERATOR)
        )
        
        val missing = getMissingIngredients(recipe, inventory)
        missing.shouldBeEmpty()
    }
})
