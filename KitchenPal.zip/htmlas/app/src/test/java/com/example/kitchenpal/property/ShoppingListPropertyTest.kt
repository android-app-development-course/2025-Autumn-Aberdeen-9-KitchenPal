package com.example.kitchenpal.property

import com.example.kitchenpal.data.model.ShoppingItem
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.shouldNotBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll

/**
 * **Feature: kitchen-pal-app, Property 7: Shopping Item Toggle Consistency**
 * **Validates: Requirements 7.2**
 * 
 * For any shopping list item, toggling the checkbox should flip the isChecked 
 * state from true to false or false to true.
 */
class ShoppingItemTogglePropertyTest : FunSpec({
    
    fun toggleItem(item: ShoppingItem): ShoppingItem {
        return item.copy(isChecked = !item.isChecked)
    }
    
    val shoppingItemArb = arbitrary {
        ShoppingItem(
            id = Arb.long(1, 1000).bind(),
            name = Arb.string(3..30).bind(),
            quantity = Arb.string(1..10).bind(),
            isChecked = Arb.boolean().bind()
        )
    }
    
    test("toggling item flips isChecked state") {
        checkAll(100, shoppingItemArb) { item ->
            val toggled = toggleItem(item)
            toggled.isChecked shouldBe !item.isChecked
        }
    }
    
    test("toggling twice returns to original state") {
        checkAll(100, shoppingItemArb) { item ->
            val toggledOnce = toggleItem(item)
            val toggledTwice = toggleItem(toggledOnce)
            toggledTwice.isChecked shouldBe item.isChecked
        }
    }
    
    test("toggling preserves other properties") {
        checkAll(100, shoppingItemArb) { item ->
            val toggled = toggleItem(item)
            toggled.id shouldBe item.id
            toggled.name shouldBe item.name
            toggled.quantity shouldBe item.quantity
        }
    }
    
    test("unchecked item becomes checked after toggle") {
        checkAll(100, Arb.string(3..30), Arb.string(1..10)) { name, quantity ->
            val uncheckedItem = ShoppingItem(id = 1, name = name, quantity = quantity, isChecked = false)
            val toggled = toggleItem(uncheckedItem)
            toggled.isChecked shouldBe true
        }
    }
    
    test("checked item becomes unchecked after toggle") {
        checkAll(100, Arb.string(3..30), Arb.string(1..10)) { name, quantity ->
            val checkedItem = ShoppingItem(id = 1, name = name, quantity = quantity, isChecked = true)
            val toggled = toggleItem(checkedItem)
            toggled.isChecked shouldBe false
        }
    }
})

/**
 * **Feature: kitchen-pal-app, Property 8: Shopping Item Deletion**
 * **Validates: Requirements 7.3**
 * 
 * For any shopping list and item in that list, deleting the item should 
 * result in the list no longer containing that item.
 */
class ShoppingItemDeletionPropertyTest : FunSpec({
    
    fun deleteItem(list: List<ShoppingItem>, itemToDelete: ShoppingItem): List<ShoppingItem> {
        return list.filter { it.id != itemToDelete.id }
    }
    
    val shoppingItemArb = arbitrary {
        ShoppingItem(
            id = Arb.long(1, 1000).bind(),
            name = Arb.string(3..30).bind(),
            quantity = Arb.string(1..10).bind(),
            isChecked = Arb.boolean().bind()
        )
    }
    
    test("deleted item is no longer in list") {
        checkAll(100, Arb.list(shoppingItemArb, 1..20)) { items ->
            if (items.isNotEmpty()) {
                val itemToDelete = items.random()
                val afterDeletion = deleteItem(items, itemToDelete)
                
                afterDeletion.none { it.id == itemToDelete.id } shouldBe true
            }
        }
    }
    
    test("deletion reduces list size by one when item exists") {
        checkAll(100, Arb.list(shoppingItemArb, 1..20)) { items ->
            if (items.isNotEmpty()) {
                val itemToDelete = items.random()
                val afterDeletion = deleteItem(items, itemToDelete)
                
                val expectedSize = items.count { it.id != itemToDelete.id }
                afterDeletion.size shouldBe expectedSize
            }
        }
    }
    
    test("other items remain unchanged after deletion") {
        checkAll(100, Arb.list(shoppingItemArb, 2..20)) { items ->
            if (items.size >= 2) {
                val itemToDelete = items.first()
                val afterDeletion = deleteItem(items, itemToDelete)
                
                items.filter { it.id != itemToDelete.id }.forEach { originalItem ->
                    afterDeletion.any { it.id == originalItem.id && it == originalItem } shouldBe true
                }
            }
        }
    }
    
    test("deleting from empty list returns empty list") {
        val emptyList = emptyList<ShoppingItem>()
        val itemToDelete = ShoppingItem(1, "Test", "1", false)
        val afterDeletion = deleteItem(emptyList, itemToDelete)
        
        afterDeletion.size shouldBe 0
    }
    
    test("deleting non-existent item does not change list") {
        checkAll(100, Arb.list(shoppingItemArb, 1..20)) { items ->
            val nonExistentItem = ShoppingItem(id = -1, name = "NonExistent", quantity = "0", isChecked = false)
            val afterDeletion = deleteItem(items, nonExistentItem)
            
            afterDeletion.size shouldBe items.size
        }
    }
})
