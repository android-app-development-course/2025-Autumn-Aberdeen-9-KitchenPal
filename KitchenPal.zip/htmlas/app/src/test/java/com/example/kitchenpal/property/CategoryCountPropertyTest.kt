package com.example.kitchenpal.property

import com.example.kitchenpal.data.model.CategoryCount
import com.example.kitchenpal.data.model.FoodCategory
import com.example.kitchenpal.data.model.FoodItem
import com.example.kitchenpal.data.model.StorageLocation
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.*
import io.kotest.property.checkAll
import java.time.LocalDate

/**
 * **Feature: kitchen-pal-app, Property 2: Category Count Accuracy**
 * **Validates: Requirements 2.1**
 * 
 * For any set of food items in the inventory, the category counts displayed 
 * on the home page should exactly match the actual count of items in each category.
 */
class CategoryCountPropertyTest : FunSpec({
    
    fun calculateCategoryCounts(items: List<FoodItem>): List<CategoryCount> {
        return FoodCategory.entries.map { category ->
            CategoryCount(
                category = category,
                count = items.count { it.category == category }
            )
        }
    }
    
    val foodItemArb = arbitrary {
        FoodItem(
            id = Arb.long(1, 1000).bind(),
            name = Arb.string(5..20).bind(),
            category = Arb.enum<FoodCategory>().bind(),
            quantity = Arb.string(1..10).bind(),
            expiryDate = Arb.localDate(
                minDate = LocalDate.now(),
                maxDate = LocalDate.now().plusDays(30)
            ).bind(),
            storageLocation = Arb.enum<StorageLocation>().bind()
        )
    }
    
    test("category counts match actual item counts for all categories") {
        checkAll(100, Arb.list(foodItemArb, 0..50)) { items ->
            val categoryCounts = calculateCategoryCounts(items)
            
            FoodCategory.entries.forEach { category ->
                val expectedCount = items.count { it.category == category }
                val actualCount = categoryCounts.find { it.category == category }?.count ?: 0
                
                actualCount shouldBe expectedCount
            }
        }
    }
    
    test("total of all category counts equals total items") {
        checkAll(100, Arb.list(foodItemArb, 0..50)) { items ->
            val categoryCounts = calculateCategoryCounts(items)
            val totalCount = categoryCounts.sumOf { it.count }
            
            totalCount shouldBe items.size
        }
    }
    
    test("empty inventory has zero counts for all categories") {
        val categoryCounts = calculateCategoryCounts(emptyList())
        
        categoryCounts.forEach { categoryCount ->
            categoryCount.count shouldBe 0
        }
    }
    
    test("all categories are represented in counts") {
        checkAll(100, Arb.list(foodItemArb, 0..20)) { items ->
            val categoryCounts = calculateCategoryCounts(items)
            
            categoryCounts.size shouldBe FoodCategory.entries.size
            FoodCategory.entries.forEach { category ->
                categoryCounts.any { it.category == category } shouldBe true
            }
        }
    }
})
