package com.example.kitchenpal.property

import com.example.kitchenpal.viewmodel.LoginViewModel
import io.kotest.core.spec.style.FunSpec
import io.kotest.matchers.shouldBe
import io.kotest.property.Arb
import io.kotest.property.arbitrary.string
import io.kotest.property.checkAll

/**
 * **Feature: kitchen-pal-app, Property 1: Empty Credentials Rejection**
 * **Validates: Requirements 1.3**
 * 
 * For any login attempt with empty or whitespace-only username or password, 
 * the system should reject the login and display an error message without 
 * navigating away from the login page.
 */
class CredentialsValidationPropertyTest : FunSpec({
    
    test("empty username should be rejected") {
        checkAll(100, Arb.string(1..50)) { password ->
            LoginViewModel.validateCredentials("", password) shouldBe false
        }
    }
    
    test("empty password should be rejected") {
        checkAll(100, Arb.string(1..50)) { username ->
            LoginViewModel.validateCredentials(username, "") shouldBe false
        }
    }
    
    test("both empty should be rejected") {
        LoginViewModel.validateCredentials("", "") shouldBe false
    }
    
    test("whitespace-only username should be rejected") {
        val whitespaceStrings = listOf(" ", "  ", "\t", "\n", "   \t\n  ")
        whitespaceStrings.forEach { whitespace ->
            LoginViewModel.validateCredentials(whitespace, "validPassword") shouldBe false
        }
    }
    
    test("whitespace-only password should be rejected") {
        val whitespaceStrings = listOf(" ", "  ", "\t", "\n", "   \t\n  ")
        whitespaceStrings.forEach { whitespace ->
            LoginViewModel.validateCredentials("validUsername", whitespace) shouldBe false
        }
    }
    
    test("valid non-empty credentials should be accepted") {
        checkAll(100, Arb.string(1..50), Arb.string(1..50)) { username, password ->
            if (username.isNotBlank() && password.isNotBlank()) {
                LoginViewModel.validateCredentials(username, password) shouldBe true
            }
        }
    }
})
